import { Text, useColorScheme } from 'react-native'
import React from 'react'
import { colors } from '../constants/colors'

const ThemedText = ({style, title = false, ...props}) => {
     const colorScheme = useColorScheme ()
        const theme = colors[colorScheme] ?? colors.light

        const textColor = title ? theme.title : theme.text
  return (
   
      <Text 
        style = {[{color : textColor}, style]}
        {...props}
       />
    
  )
}

export default ThemedText